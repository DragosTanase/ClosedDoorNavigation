package com.example.aplicatieactuala;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorManager;
import android.os.CountDownTimer;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Timer;
import java.util.TimerTask;

public class StepSensorAcceleration extends StepSensorBase{

    private final int valueNum = 5;
    private float[] tempValue = new float[valueNum];
    private int tempCount = 0;
    private boolean isDirectionUp = false;
    private int continueUpCount = 0;
    private int continueUpFormerCount = 0;
    private boolean lastStatus = false;
    private float peakOfWave = 0;
    private float valleyOfWave = 0;
    private long timeOfThisPeak = 0;
    private long timeOfLastPeak = 0;
    private long timeOfNow = 0;
    private float gravityOld = 0;
    private final float initialValue = (float) 1.7;
    private float ThreadValue = (float) 2.0;
    private float minValue = 11f;
    private float maxValue = 19.6f;
    private int CountTimeState = 0;
    private static int TEMP_STEP = 0;
    private int lastStep = -1;
    private static float average = 0;
    private long duration = 3500;


    public StepSensorAcceleration(Context context, StepCallBack stepCallBack) {
        super(context, stepCallBack);
    }


    @Override
    protected void registerStepListener() {

        isAvailable = sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
                SensorManager.SENSOR_DELAY_UI, SensorManager.SENSOR_DELAY_UI);

    }

    @Override
    public void unregisterStep() {
        sensorManager.unregisterListener(this);
    }

    public void onAccuracyChanged(Sensor arg0, int arg1) {
    }

    public void onSensorChanged(SensorEvent event) {

        Sensor sensor = event.sensor;
        synchronized (this) {
            if (sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                    calc_step(event);
            }
        }
    }


    synchronized private void calc_step(SensorEvent event) {
        average = (float) Math.sqrt(Math.pow(event.values[0], 2)
                + Math.pow(event.values[1], 2) + Math.pow(event.values[2], 2));
        detectorNewStep(average);

    }

    public void detectorNewStep(float values) {
        if (gravityOld == 0) {
            gravityOld = values;
        } else {
            if (DetectorPeak(values, gravityOld)) {
                timeOfLastPeak = timeOfThisPeak;
                timeOfNow = System.currentTimeMillis();

                if (timeOfNow - timeOfLastPeak >= 200
                        && (peakOfWave - valleyOfWave >= ThreadValue) && (timeOfNow - timeOfLastPeak) <= 2000) {
                    timeOfThisPeak = timeOfNow;

                    preStep();
                }
                if (timeOfNow - timeOfLastPeak >= 200
                        && (peakOfWave - valleyOfWave >= initialValue)) {
                    timeOfThisPeak = timeOfNow;
                    ThreadValue = Peak_Valley_Thread(peakOfWave - valleyOfWave);
                }
            }
        }
        gravityOld = values;
    }

    private void preStep() {
        StepSensorBase.CURRENT_STEP++;
        stepCallBack.Step(StepSensorBase.CURRENT_STEP);
    }

    public boolean DetectorPeak(float newValue, float oldValue) {
        lastStatus = isDirectionUp;
        if (newValue >= oldValue) {
            isDirectionUp = true;
            continueUpCount++;
        } else {
            continueUpFormerCount = continueUpCount;
            continueUpCount = 0;
            isDirectionUp = false;
        }

        if (!isDirectionUp && lastStatus
                && (continueUpFormerCount >= 2 && (oldValue >= minValue && oldValue < maxValue))) {
            peakOfWave = oldValue;
            return true;
        } else if (!lastStatus && isDirectionUp) {
            valleyOfWave = oldValue;
            return false;
        } else {
            return false;
        }
    }

    public float Peak_Valley_Thread(float value) {
        float tempThread = ThreadValue;
        if (tempCount < valueNum) {
            tempValue[tempCount] = value;
            tempCount++;
        } else {
            tempThread = averageValue(tempValue, valueNum);
            System.arraycopy(tempValue, 1, tempValue, 0, valueNum - 1);
            tempValue[valueNum - 1] = value;
        }
        return tempThread;

    }

    public float averageValue(float[] value, int n) {
        float ave = 0;
        for (int i = 0; i < n; i++) {
            ave += value[i];
        }
        ave = ave / valueNum;
        if (ave >= 8) {

            ave = (float) 4.3;
        } else if (ave >= 7) {

            ave = (float) 3.3;
        } else if (ave >= 4) {

            ave = (float) 2.3;
        } else if (ave >= 3) {

            ave = (float) 2.0;
        } else {

            ave = (float) 1.7;
        }
        return ave;
    }

}
