package com.example.uisimplu;

//import the neccesary libraries related to sensor data

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

//import the neccesary library related to writing data in a file
import java.io.FileNotFoundException;

//create the barometer class which inherit the base class Senzor

public class Barometer extends Senzor
{
    //class attributes

    ///attributes related to sensors

    protected SensorManager sensorManager;
    protected Sensor pressureSensor;

    //attribute related to desired  value(atmospheric pressure) which will be written in csv file
    protected  float pressure;

    ///create a sensorEventListener  object
    protected SensorEventListener sensorEventListener = new SensorEventListener()
    {
        @Override
        public void onSensorChanged(SensorEvent sensorEvent)
        {
            ///data obtained from sensor which will be written in csv file

            ///we will obtain an array with size n

            ///once means that we start with the head of the table

            ///data obtained from sensor which will be written in csv file
            pressure = sensorEvent.values[0];

            ///Obtain a string line from read pressure value
            String entry = "\n" + String.format("%.3f", pressure);
            try
            {
                //write the line in csv file
                writeCSV("/barometer.csv", "pressure", entry);
            }

            //treat the exception for file inadvertency and print the possible stack errors
            catch (FileNotFoundException e)
            {
                e.printStackTrace();
            }
        }
        @Override
        public void onAccuracyChanged(Sensor sensor, int i)
        {
            ///nothing
        }
    };
}