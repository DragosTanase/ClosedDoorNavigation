package com.example.uisimplu;

//import the sensor and file libraries
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import java.io.FileNotFoundException;


//create the Gyroscope class which inherit the base class Senzor

public class Gyroscope extends Senzor
{
    //class attributes related to gyroscope sensors
    protected SensorManager mSensorManager;
    protected Sensor mGyroscope;

    //class attributed related to x,y,z coordinated obtained from gyroscope senzors
    protected float xGyroscope ;
    protected float yGyroscope ;
    protected float zGyroscope ;

    //implied constructor
    Gyroscope() {};

    ///create a sensorEventListener object
    protected SensorEventListener sensorEventListener = new SensorEventListener()
    {
        ///overridden method for collecting the coordinates for each spacial change
        @Override
        public void onSensorChanged(SensorEvent sensorEvent)
        {
            ///for each location point we have an array with size 3 where x,y,z coordinates are stored
            xGyroscope = sensorEvent.values[0];
            yGyroscope = sensorEvent.values[1];
            zGyroscope = sensorEvent.values[2];

            //string variable - line that contains x,y,z values
            String entry = "\n" + String.format("%.2f", xGyroscope) + "," + String.format("%.2f", yGyroscope) + "," + String.format("%.2f", zGyroscope);
            try
            {
                //condition - values mustn't be equal to 0
                if(xGyroscope!=0.00 && yGyroscope!=0.00)
                {
                    //writing data only when moving line by line
                    writeCSV("/gyroscope.csv", "X" + ", " + "Y" + ", " + "Z", entry);
                }
            }

            //when file couldn't be found we can see all the related reasons by logging all the errors
            catch (FileNotFoundException e)
            {
                e.printStackTrace();
            }
        }
        @Override
        public void onAccuracyChanged(Sensor sensor, int i)
        {
            ///nothing
        }
    };
}