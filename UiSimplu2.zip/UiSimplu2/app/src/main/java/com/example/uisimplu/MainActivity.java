package com.example.uisimplu;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements LocationListener, OrientSensor.OrientCallBack, StepSensorBase.StepCallBack
{
    //class attributes - sensor type objects

    Accelerometer accelerometer = new Accelerometer();
    WifiSignal wifiSignal = new WifiSignal();
    Gyroscope gyroscope = new Gyroscope();
    Magnetometer magnetometer = new Magnetometer();
    Barometer barometer = new Barometer();
    Bluetooth bluetooth = new Bluetooth();
    StepCounter stepCounter = new StepCounter();
    Senzor senzor = new Senzor();
    protected StepSensorBase mStepSensor;
    MobileData mobileData = new MobileData();
    GPS gps = new GPS();
    protected boolean ok = true;

    //   String pinPointHeader ="\n\n"+"x_acc" + "," + "y_acc" + "," + "z_acc" + "," + "x_gyro" + "," + "y_gyro" + "," + "z_gyro" + "," + "mag_tesla" + "," + "wifi_rssi"+","+"denumire";
    String pinPointHeader ="x_acc" + "," + "y_acc" + "," + "z_acc" + "," + "x_gyro" + "," + "y_gyro" + "," + "z_gyro" + "," + "mag_tesla" + "," + "wifi_rssi"+","+"denumire";


    //citire din fisier pt spinner

    private Spinner spinner;

    ArrayList<String> list = new ArrayList<>();

    File f1 = new File("/storage/emulated/0/Download/PinPoints.csv");
    List<String> lista;

    {
        try {
            lista = Files.readAllLines(f1.toPath(), StandardCharsets.UTF_8);
            for(String l: lista){
                String [] array=l.split(",",-1);
                if(array[array.length-1].equals("denumire")) {
                    continue;
                }else {
                    list.add(array[array.length - 1]);
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    //////////////////////////////////////////////////////////////////////////////////////

    //
    private Canvas mCanvas;
    private int mStepLen = 50; // step length
    protected OrientSensor mOrientSensor;

    //canvas methods for step counter and associated orientation
    @Override
    public void Step(int stepNum)
    {
        mCanvas.autoAddPoint(mStepLen);
    }

    @Override
    public void Orient(int orient)
    {
        mCanvas.autoDrawArrow(orient);
    }

    //button for orient sensor
    public void OrientClick()
    {
        mOrientSensor = new OrientSensor(this, this);
        if (!mOrientSensor.registerOrient())
        {
            Toast.makeText(this, "orientu nu e disponibil！", Toast.LENGTH_SHORT).show();
        }

    }

    public void StepClick()
    {
        mStepSensor = new StepSensorAcceleration(this, this);
        if (!mStepSensor.registerStep())
        {
        }

    }


    @Override

    //a method that cretates the bundle of the app
    protected void onCreate(Bundle savedInstanceState)
    {
        //layout and canvas
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mCanvas = (Canvas) findViewById(R.id.step_surfaceView);

        //connect to different types of sensors
        gps.locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        barometer.sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        barometer.pressureSensor = barometer.sensorManager.getDefaultSensor(Sensor.TYPE_PRESSURE);
        wifiSignal.wifiManager = (WifiManager) this.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        accelerometer.mSensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
        accelerometer.mAccelerator = accelerometer.mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        gyroscope.mSensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
        gyroscope.mGyroscope = gyroscope.mSensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        magnetometer.magSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        magnetometer.magSensor = magnetometer.magSensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        stepCounter.msensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        stepCounter.mStepCounter=stepCounter.msensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);

        //if else for sensor permision request on app
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_DENIED)
        {
            requestPermissions(new String[]{Manifest.permission.ACTIVITY_RECOGNITION}, 0);
        }
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.MANAGE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED)
        {
            requestPermissions(new String[]{Manifest.permission.MANAGE_EXTERNAL_STORAGE}, 0);
        }
        if (ContextCompat.checkSelfPermission(  MainActivity.this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED)
        {
            bluetooth.BTAdapter.startDiscovery();
        }
//        MobileData.myPhoneStateListener pslistener = mobileData.new myPhoneStateListener();

        Handler mainHandler2 = new Handler(Looper.getMainLooper());
        final Runnable[] r4 = new Runnable[1];



        //Handler mainHandler2 = new Handler(Looper.getMainLooper());
        //final Runnable[] r4 = new Runnable[1];




        //PIN POINT

        Button button_pin_point;
        button_pin_point = (Button) findViewById(R.id.buttonPP);
        button_pin_point.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                openDialog();

                String pinEntry = pinPointHeader + "\n" + accelerometer.xAccelerometer + "," + accelerometer.yAccelerometer + "," + accelerometer.zAccelerometer + "," + gyroscope.xGyroscope + "," + gyroscope.yGyroscope + "," + gyroscope.zGyroscope + "," + magnetometer.tesla + "," + wifiSignal.rssi+",";
                try {
                    senzor.writeCSV("/PinPoints.csv", "", pinEntry);
                    pinPointHeader = "";
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }

            public void openDialog() {
                PopUpWindow exampleDialog = new PopUpWindow();
                exampleDialog.show(getSupportFragmentManager(), "example dialog");
            }
        });



        //SPINNER PP

        spinner=findViewById(R.id.spinnerPP);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, list);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(MainActivity.this,spinner.getSelectedItem().toString(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {


            }
        });


        //START


        //start/stop button for reading data/stop reading data functionality
        Button startBtn = findViewById(R.id.buttonStart);
        startBtn.setOnClickListener(new View.OnClickListener()
        {
            // a method which occurs when the start/stop button is touched
            @Override
            public void onClick(View v)
            {
                if (ok)
                {
                    startBtn.setText("STOP");
                    ok = false;

                    OrientClick();
                    StepClick();

                    //registerListener for different types of sensors
                    accelerometer.mSensorManager.registerListener(accelerometer.sensorEventListener, accelerometer.mAccelerator, SensorManager.SENSOR_DELAY_NORMAL);
                    stepCounter.msensorManager.registerListener(stepCounter.sensorEventListener, stepCounter.mStepCounter, SensorManager.SENSOR_DELAY_NORMAL);
                    barometer.sensorManager.registerListener(barometer.sensorEventListener, barometer.pressureSensor, SensorManager.SENSOR_DELAY_UI);
                    gyroscope.mSensorManager.registerListener(gyroscope.sensorEventListener, gyroscope.mGyroscope, SensorManager.SENSOR_DELAY_NORMAL);
                    magnetometer.magSensorManager.registerListener(magnetometer.sensorEventListener, magnetometer.magSensor, SensorManager.SENSOR_DELAY_NORMAL);
//                    mobileData.telephoneManager  = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
                    //Bluetooth
                    registerReceiver(bluetooth.receiver, new IntentFilter(BluetoothDevice.ACTION_FOUND));
                    Handler bluHandler = new Handler(Looper.getMainLooper());
                    final Runnable r2 = new Runnable()
                    {
                        @Override
                        public void run() {
                            bluHandler.postDelayed(this, 1000);
                        }
                    };
                    bluHandler.postDelayed(r2, 1000);
                    //GPS

                    //user permissions for catching the sensor signal
                    if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
                            && (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED))
                    {
                        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, 1);
                    }
                    gps.locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, (LocationListener) MainActivity.this);
                    //Mobile Data
//                    mobileData.telephoneManager.listen(pslistener, PhoneStateListener.LISTEN_SIGNAL_STRENGTHS);
//                    SignalStrength signalStrength = mobileData.telephoneManager.getSignalStrength();
//                    pslistener.onSignalStrengthsChanged(signalStrength);
                    //Wifi
                    r4[0] = new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            wifiSignal.displayWifiData();
                            mainHandler2.postDelayed(this, 100);
                        }
                    };
                    mainHandler2.postDelayed(r4[0], 100);
                    //save in csv start value
                    Handler startRecHandler = new Handler(Looper.getMainLooper());
                    startRecHandler.postDelayed(new Runnable()
                    {
                        //start reading data through a handler created before
                        public void run()
                        {
                            String startHeader= "data_pres, x_acc, y_acc, z_acc, x_gyro, y_gyro, z_gyro, mag_tesla, wifi_rssi, steps" + "\n";
                            String startEntry =  barometer.pressure + "," + accelerometer.xAccelerometer + "," + accelerometer.yAccelerometer + "," + accelerometer.zAccelerometer + "," + gyroscope.xGyroscope + "," + gyroscope.yGyroscope + "," + gyroscope.zGyroscope + "," + magnetometer.tesla + "," + wifiSignal.rssi + "," + stepCounter.stepCount+"\n";
                            try
                            {
                                senzor.writeCSV("/start.csv", startHeader, startEntry);
                            }
                            catch (FileNotFoundException e)
                            {
                                e.printStackTrace();
                            }
                        }
                    },200);
                }
                else
                {
                    //when we want to stop reading sensor data and writing collected values in csv files
                    startBtn.setText("START");
                    ok = true;
                    accelerometer.mSensorManager.unregisterListener(accelerometer.sensorEventListener, accelerometer.mAccelerator);
                    stepCounter.msensorManager.unregisterListener(stepCounter.sensorEventListener, stepCounter.mStepCounter);
                    barometer.sensorManager.unregisterListener(barometer.sensorEventListener, barometer.pressureSensor);
                    gyroscope.mSensorManager.unregisterListener(gyroscope.sensorEventListener, gyroscope.mGyroscope);
                    magnetometer.magSensorManager.unregisterListener(magnetometer.sensorEventListener, magnetometer.magSensor);
                    gps.locationManager.removeUpdates((LocationListener) MainActivity.this);
                    mOrientSensor.unregisterOrient();
                    mStepSensor.unregisterStep();
//                    mobileData.telephoneManager.listen(pslistener,PhoneStateListener.LISTEN_NONE);
                    //Bluetooth
                    unregisterReceiver(bluetooth.receiver);
                    Handler bluHandler = new Handler(Looper.getMainLooper());
                    final Runnable r2 = new Runnable()
                    {
                        @Override
                        public void run() {
                            bluHandler.postDelayed(this, 1000);
                        }
                    };
                    bluHandler.postDelayed(r2, 1000);
                    bluHandler.removeCallbacks(r2);
                    //Wifi
                    mainHandler2.removeCallbacks(r4[0]);
                    String stopHeader="data_pres, x_acc, y_acc, z_acc, x_gyro, y_gyro, z_gyro, mag_tesla, wifi_rssi, steps" + "\n";
                    String stopEntry = barometer.pressure + "," + accelerometer.xAccelerometer + "," + accelerometer.yAccelerometer + "," + accelerometer.zAccelerometer + "," + gyroscope.xGyroscope + "," + gyroscope.yGyroscope + "," + gyroscope.zGyroscope + "," + magnetometer.tesla + "," + wifiSignal.rssi + "," + stepCounter.stepCount+"\n";
                    try
                    {
                        senzor.writeCSV("/stop.csv", stopHeader, stopEntry);
                    }
                    catch (FileNotFoundException e)
                    {
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    protected void onResume()
    {
        super.onResume();
    }
    @Override
    protected void onPause()
    {
        super.onPause();
    }

    //END MAIN//

    ///// GPS LATITUDE AND LONGITUDE VALUES //////////
    @Override
    //method for GPS sensor that collect lat and long values and writes them in csv
    public void onLocationChanged(@NonNull Location location)
    {
        float latitude = (float)location.getLatitude();
        float longitude =  (float)location.getLongitude();
        String entry = "\n" + String.format("%.4f", latitude) + "," + String.format("%.4f", longitude);
        try
        {
            senzor.writeCSV("/gps.csv", "latitude" + ", " + "longitude", entry);
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
    }
}