package com.example.uisimplu;

//import context and hardware sensor libraries
import android.content.Context;
import android.hardware.SensorManager;

//import java file libraries
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

//import java stack libraries
import java.util.Stack;

public class Senzor
{
    //class attributes

    //attributes related to file
    protected File path = new File("/storage/emulated/0/Download");
    protected File file;
    protected FileOutputStream f;

    //attributes related to movements(seonsor ,orientation,steps)
    private static final int SENSE = 10;
    private static final int STOP_COUNT = 6;
    private int initialOrient = -1;
    private int endOrient = -1;
    private boolean isRotating = false;
    private int lastDOrient = 0;
    private Stack<Integer> dOrientStack = new Stack<>();
    Senzor(){};
    private static final Senzor sensorUtil = new Senzor(); //constanta Singleton
    private SensorManager sensorManager;

    public static Senzor getInstance()
    {
        return sensorUtil;
    }

    public SensorManager getSensorManager(Context context)
    {
        if (sensorManager == null)
        {
            sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        }
        return sensorManager;
    }

    //a method that returns the orientation value
    public int getRotateEndOrient(int orient)
    {
        //case when initialOrient is -1
        if (initialOrient == -1)
        {
            endOrient = initialOrient = orient;
        }

        int currentDOrient = Math.abs(orient - initialOrient);

        //case when during walking we don't make any rotation
        if (!isRotating)
        {
            lastDOrient = currentDOrient;
            if (lastDOrient >= SENSE)
            {
                isRotating = true;
            }
        }

        //case when during walking we make at least a rotation
        else
        {
            //subcase when current orientation is less than or equal to last orient
            if (currentDOrient <= lastDOrient)
            {
                int size = dOrientStack.size();
                if (size >= STOP_COUNT)
                {
                    for (int i = 0; i < size; i++)
                    {
                        if (Math.abs(currentDOrient - dOrientStack.pop()) >= SENSE)
                        {
                            isRotating = true;
                            break;
                        }
                        isRotating = false;
                    }
                }
                //when we have the any rotation subcase we clear the stack and reinitialize
                //the initial orient with -1
                if (!isRotating)
                {
                    dOrientStack.clear();
                    initialOrient = -1;
                    endOrient = orient;
                }
                else
                {
                    dOrientStack.push(currentDOrient);
                }
            }

            //subcase when current orientation is greater than last orient
            else
            {
                lastDOrient = currentDOrient;
            }
        }
        return endOrient;
    }

    //method that writes in CSV the head table and associated data
    public void writeCSV(String fileName, String once, String entry) throws FileNotFoundException
    {

        file = new File(path + fileName);
        f = new FileOutputStream(file, true);
        if(file.length()!=0)
        {
            try
            {
                f.write(entry.getBytes());
                f.flush();
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }
        else
        {
            try
            {
                f.write(once.getBytes());
                f.write(entry.getBytes());
                f.flush();
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }

    }
}