package com.example.uisimplu;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorManager;

/**
 * Step counting sensor
 */


public class StepSensorPedometer extends StepSensorBase
{
    //private int lastStep = -1;
    private int liveStep = 0;
   // private int increment = 0;
    private int sensorMode = 0;//Step counting sensor type
    public StepSensorPedometer(Context context, StepCallBack stepCallBack) {
        super(context, stepCallBack);
    }

    @Override
    protected void registerStepListener()
    {
        Sensor detectorSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);
        Sensor countSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        if (sensorManager.registerListener(this, detectorSensor, SensorManager.SENSOR_DELAY_GAME))
        {
            isAvailable = true;
            sensorMode = 0;//Step counting sensor Detector available!

        } else if (sensorManager.registerListener(this, countSensor, SensorManager.SENSOR_DELAY_GAME))
        {
            isAvailable = true;
            sensorMode = 1;//Step counting sensor Counter is available
        }
        else
        {
            isAvailable = false;//Step counting sensor is not available!
        }
    }
    @Override
    public void unregisterStep()
    {
        sensorManager.unregisterListener(this);
    }

    @Override
    //method that update the number of steps for each sensor changing
    public void onSensorChanged(SensorEvent event)
    {
        liveStep = (int) event.values[0];
        if (sensorMode == 0)
        {
            StepSensorBase.CURRENT_STEP += liveStep;//Number of steps
        }
        else if (sensorMode == 1)
        {
            StepSensorBase.CURRENT_STEP = liveStep;//Number of steps
        }
        stepCallBack.Step(StepSensorBase.CURRENT_STEP);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy)
    {
        ///nothing
    }

}