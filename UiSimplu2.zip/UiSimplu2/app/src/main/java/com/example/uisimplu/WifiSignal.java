package com.example.uisimplu;

import android.net.wifi.WifiManager;
import java.io.FileNotFoundException;

public class WifiSignal extends Senzor
{
    ///class attributes

    protected WifiManager wifiManager;
    protected int rssi;
    protected  int level;
    WifiSignal(){};


    ///class method that gets and writes in a csv the rssi and its associated level
    public void displayWifiData()
    {
        rssi = wifiManager.getConnectionInfo().getRssi();
        level = wifiManager.calculateSignalLevel(rssi);
        String entry = "\n" + rssi;
        try
        {
            writeCSV("/wifiSignal.csv", "RSSI", entry);
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }

    }
}
