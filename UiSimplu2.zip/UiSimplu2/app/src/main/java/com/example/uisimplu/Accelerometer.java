package com.example.uisimplu;



import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import java.io.FileNotFoundException;

//create the Accelerometer class which inherit the base class Senzor


public class Accelerometer extends Senzor
{
    //class attributes

    ///attributes related to sensors
    protected SensorManager mSensorManager;
    protected Sensor mAccelerator;

    ///attributes related to desired  values (x,y,z,coordinates)
    protected  float xAccelerometer;
    protected float yAccelerometer;
    protected float zAccelerometer;


    Accelerometer(){};


    ///create a sensorEventListener  object
    protected SensorEventListener sensorEventListener = new SensorEventListener()
    {

        ///overridden method for collecting the coordinates for each spacial change
        @Override
        public void onSensorChanged(SensorEvent sensorEvent)
        {
            ///for each location point we have an array with size 3 where x,y,z coordinates are stored
            ///for each array we write a line in csv file
            ///finally all the data written in csv file will look like a matrix with n lines and 3 columns
            xAccelerometer = sensorEvent.values[0];
            yAccelerometer = sensorEvent.values[1];
            zAccelerometer = sensorEvent.values[2];

            //string variable -line that contains x,y,z values
            String entry = "\n" + String.format("%.2f", xAccelerometer) + "," + String.format("%.2f", yAccelerometer) + "," + String.format("%.2f", zAccelerometer);
            try
            {
                //writing when ignoring the constant acceleration
                if(xAccelerometer!=0.00 && yAccelerometer!=9.81)
                {
                    writeCSV("/accelerometer.csv", "X" + ", " + "Y" + ", " + "Z", entry);
                }
            }
            //when file couldn't be found we can see all the related reasons by logging all the errors
            catch (FileNotFoundException e)
            {
                e.printStackTrace();
            }
        }
        @Override
        public void onAccuracyChanged(Sensor sensor, int i)
        {
            //nothing
        }
    };



}