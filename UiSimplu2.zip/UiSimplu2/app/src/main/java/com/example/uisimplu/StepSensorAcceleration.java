package com.example.uisimplu;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorManager;
import android.os.CountDownTimer;


import java.util.Timer;
import java.util.TimerTask;

public class StepSensorAcceleration extends StepSensorBase
{
    //stores three-axis data

    final int valueNum = 5;

    //Used to store the crest and trough differences for calculated thresholds
    float[] tempValue = new float[valueNum];
    int tempCount = 0;

    //Whether the flag bit is rising
    boolean isDirectionUp = false;

    /// Number of consecutive upward movements
    int continueUpCount = 0;

    //The number of times the previous point continues to rise, in order to record the number of rises of the peaks
    int continueUpFormerCount = 0;

    //The state of the previous point, up or down
    boolean lastStatus = false;

    //Wave peaks
    float peakOfWave = 0;
    float valleyOfWave = 0;

    //The timing of this peak
    long timeOfThisPeak = 0;

    //The time of the last peak
    long timeOfLastPeak = 0;

    //The current time
    long timeOfNow = 0;

    // The value of the current sensor
    float gravityNew = 0;

    // The value of the last sensor
    float gravityOld = 0;

    //  Dynamic thresholds require dynamic data, and this value is used for the thresholds for these dynamic data
    final float initialValue = (float) 1.7;

    //Initial threshold
    float ThreadValue = (float) 2.0;

    //Initial scope
    float minValue = 11f;
    float maxValue = 19.6f;

    /**
     * 0 - Ready to time 1 - Time in 2 - Normal step counting
     */
    private int CountTimeState = 0;
    public static int TEMP_STEP = 0;
    private int lastStep = -1;
    //   The average value calculated from the three dimensions of the x, y, and z axes
    public static float average = 0;
    private Timer timer;
    // Countdown is 3.5 seconds, and no steps are displayed within 3.5 seconds to shield against subtle fluctuations
    private long duration = 3500;
    private TimeCount time;

    public StepSensorAcceleration(Context context, StepCallBack stepCallBack) {
        super(context, stepCallBack);
    }


    @Override
    protected void registerStepListener()
    {
        // Register the accelerometer
        isAvailable = sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_GAME);

    }

    @Override
    public void unregisterStep()
    {
        sensorManager.unregisterListener(this);
    }

    public void onAccuracyChanged(Sensor arg0, int arg1)
    {
        //nothing
    }

    public void onSensorChanged(SensorEvent event)
    {
        Sensor sensor = event.sensor;
        synchronized (this)
        {
            if (sensor.getType() == Sensor.TYPE_ACCELEROMETER)
            {
                calc_step(event);
            }
        }
    }
    synchronized private void calc_step(SensorEvent event)
    {
        average = (float) Math.sqrt(Math.pow(event.values[0], 2) + Math.pow(event.values[1], 2) + Math.pow(event.values[2], 2));
        detectorNewStep(average);
    }

    /*
     * Detect steps and start counting steps
     * 1. Data passed into the sensor
     * 2. If the peak is detected and the conditions of time difference and threshold are met, it is judged to be 1 step
     * 3. If the time difference condition is met, and the crest and trough difference is greater than the initialValue, the difference is included in the calculation of the threshold
     * */

    public void detectorNewStep(float values)
    {
        if (gravityOld == 0) {
            gravityOld = values;
        } else
        {
            if (DetectorPeak(values, gravityOld))
            {
                timeOfLastPeak = timeOfThisPeak;
                timeOfNow = System.currentTimeMillis();
                if (timeOfNow - timeOfLastPeak >= 200 && (peakOfWave - valleyOfWave >= ThreadValue) && (timeOfNow - timeOfLastPeak) <= 2000)
                {
                    timeOfThisPeak = timeOfNow;
                    preStep();
                }
                if (timeOfNow - timeOfLastPeak >= 200 && (peakOfWave - valleyOfWave >= initialValue))
                {
                    timeOfThisPeak = timeOfNow;
                    ThreadValue = Peak_Valley_Thread(peakOfWave - valleyOfWave);
                }
            }
        }
        gravityOld = values;
    }

    private void preStep()
    {
        StepSensorBase.CURRENT_STEP++;
        stepCallBack.Step(StepSensorBase.CURRENT_STEP);
    }

    /*
     * Detect peaks
     * The following four conditions are judged as peaks:
     * 1. The current point is a downward trend: isDirectionUp is false
     * 2. The previous point is an uptrend: lastStatus is true
     * 3. Until the peak of the wave, the continuous rise is greater than or equal to 2 times
     * 4. Wave peak is greater than 1.2g, less than 2g
     * Record trough values
     * 1. Looking at the waveform chart, it can be found that where the steps appear, the next trough is the crest, which has more obvious characteristics and differences
     * 2. So record the trough value of each time, in order to compare it with the next peak
     * */

    public boolean DetectorPeak(float newValue, float oldValue)
    {
        lastStatus = isDirectionUp;
        if (newValue >= oldValue)
        {
            isDirectionUp = true;
            continueUpCount++;
        } else {
            continueUpFormerCount = continueUpCount;
            continueUpCount = 0;
            isDirectionUp = false;
        }

        if (!isDirectionUp && lastStatus && (continueUpFormerCount >= 2 && (oldValue >= minValue && oldValue < maxValue)))
        {
            peakOfWave = oldValue;
            return true;
        }
        else if (!lastStatus && isDirectionUp)
        {
            valleyOfWave = oldValue;
            return false;
        }
        else
        {
            return false;
        }
    }

    /*
     * Calculation of thresholds
     * 1. Calculate the threshold from the difference of the crests and troughs
     * 2. Record 4 values and store them in the tempValue[] array
     * 3. Calculate the threshold in the array passing into the function averageValue
     * */

    public float Peak_Valley_Thread(float value)
    {
        float tempThread = ThreadValue;
        if (tempCount < valueNum)
        {
            tempValue[tempCount] = value;
            tempCount++;
        }
        else
        {
            tempThread = averageValue(tempValue, valueNum);
            System.arraycopy(tempValue, 1, tempValue, 0, valueNum - 1);
            tempValue[valueNum - 1] = value;
        }
        return tempThread;
    }

    /*
     * Gradient threshold
     * 1. Calculate the mean of the array
     * 2. Gradient the threshold into a range by mean
     * */

    public float averageValue(float[] value, int n)
    {
        float ave = 0;
        for (int i = 0; i < n; i++)
        {
            ave += value[i];
        }
        ave = ave / valueNum;
        if (ave >= 8)
        {
            ave = (float) 4.3;
        }
        else if (ave >= 7)
        {
            ave = (float) 3.3;
        }
        else if (ave >= 4)
        {
            ave = (float) 2.3;
        }
        else if (ave >= 3)
        {
            ave = (float) 2.0;
        }
        else
        {
            ave = (float) 1.7;
        }
        return ave;
    }
    class TimeCount extends CountDownTimer
    {
        public TimeCount(long millisInFuture, long countDownInterval)
        {
            super(millisInFuture, countDownInterval);
        }
        @Override

        // If the timer ends gracefully, the step count begins
        public void onFinish()
        {
            time.cancel();
            StepSensorBase.CURRENT_STEP += TEMP_STEP;
            lastStep = -1;
            timer = new Timer(true);
            TimerTask task = new TimerTask() {
                public void run() {
                    if (lastStep == StepSensorBase.CURRENT_STEP)
                    {
                        timer.cancel();
                        CountTimeState = 0;
                        lastStep = -1;
                        TEMP_STEP = 0;
                    } else
                    {
                        lastStep = StepSensorBase.CURRENT_STEP;
                    }
                }
            };
            timer.schedule(task, 0, 2000);
            CountTimeState = 2;
        }

        @Override
        public void onTick(long millisUntilFinished)
        {
            if (lastStep == TEMP_STEP)
            {
                time.cancel();
                CountTimeState = 0;
                lastStep = -1;
                TEMP_STEP = 0;
            }
            else
            {
                lastStep = TEMP_STEP;
            }
        }
    }
}