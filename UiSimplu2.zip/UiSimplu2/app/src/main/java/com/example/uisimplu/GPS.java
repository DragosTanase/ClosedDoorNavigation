package com.example.uisimplu;

//import the ;location libraries
import android.location.Location;
import android.location.LocationManager;

////create the GPS class which inherit the base class Senzor
public class GPS extends Senzor
{
    //class attributes related to location
    protected LocationManager locationManager;
    protected Location location;
}