package com.example.uisimplu;

import android.content.Context;

//import hardware libraries for sensors
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

//create class orientSensor that implements SensorEventListener interface
public class OrientSensor implements SensorEventListener
{
    //class attributes

    //attributes related to sensors and orient
    private SensorManager sensorManager;
    private final OrientCallBack orientCallBack;
    private final Context context;

    //attributes related to arrays which stored collected values from sensors
    float[] accelerometerValues = new float[3];
    float[] magneticValues = new float[3];

    //constructor with parameters
    public OrientSensor(Context context, OrientCallBack orientCallBack)
    {
        this.context = context;
        this.orientCallBack = orientCallBack;
    }

    //orient callback interface which contains orient method prototypes
    public interface OrientCallBack
    {
        void Orient(int orient);
        void OrientClick();
    }

    //class methods

    //method that decides whether we should or shouldn't register the orient data based on sensor presence or absence
    public Boolean registerOrient()
    {
        boolean isAvailable = true;
        sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_GAME))
        {
            ///
        }
        else
        {
            isAvailable = false;
        }

        if (sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD),
                SensorManager.SENSOR_DELAY_GAME))
        {
            ///
        }
        else
        {
            isAvailable = false;
        }
        return isAvailable;
    }

    //method that unregister the orient sensor
    public void unregisterOrient()
    {
        sensorManager.unregisterListener(this);
    }
    @Override

    //method that collect/clone data <accelerometer and magnetic values>  and combine them
    //in order to get the rotation matrix and the associated orientation
    public void onSensorChanged(SensorEvent event)
    {
        //get accelerometer values
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER)
        {
            accelerometerValues = event.values.clone();
        }
        //get magnetic values
        else if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD)
        {
            magneticValues = event.values.clone();
        }

        //declare an array of floats with size 9
        float[] R = new float[9];

        //declare an array of floats with size 3 that store x,y,z coordinates
        float[] values = new float[3];
        SensorManager.getRotationMatrix(R, null, accelerometerValues, magneticValues);
        SensorManager.getOrientation(R, values);

        //convert to degrees the first value of sensors
        int degree = (int) Math.toDegrees(values[0]);

        //if the value of degrees is less than 0 we should increase with 360 to obtain a value between
        //0 and 359
        if (degree < 0)
        {
            degree += 360;
        }
        orientCallBack.Orient(degree);
    }
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy)
    {
        ///nothing
    }
}