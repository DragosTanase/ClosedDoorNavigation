package com.example.uisimplu;

//import the neccessary libraries for sensors and file for data writing

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import java.io.FileNotFoundException;

//create the Accelerometer class which inherit the base class Senzor
public class Magnetometer extends Senzor
{
    //class attributes

    //attributes related to sensors
    protected SensorManager magSensorManager;
    protected Sensor magSensor;

    //attributes related to values obtained from sensors and that will be written in csv file
    protected float azimuth ; // angular measurement in a spherical coordinate system
    protected float pitch ;//rotation around y axis
    protected float roll;//rotation around x axis
    protected double tesla ;//magnetic field force calculated using azimuth,pitch and roll value

    //implied constructor
    Magnetometer() {};

    ///create a sensorEventListener  object
    protected SensorEventListener sensorEventListener = new SensorEventListener()
    {
        ///overridden method for collecting the coordinates for each spacial change
        public void onSensorChanged(SensorEvent sensorEvent)
        {
            //get magnetometer sensor values from sensor event array (size 3 )
            azimuth = Math.round(sensorEvent.values[0]); // angular measurement in a spherical coordinate system
            pitch = Math.round(sensorEvent.values[1]);
            roll = Math.round(sensorEvent.values[2]);

            //calculate tesla value
            tesla = Math.sqrt((azimuth * azimuth) + (pitch * pitch) + (roll * roll)); // magnetic field strength

            //create a string variable that contains all the 4 values
            String entry = "\n" + String.format("%.3f", azimuth) + "," + String.format("%.3f", pitch) + "," + String.format("%.3f", roll) + ", " + String.format("%.3f", tesla);
            try
            {
                //write the entry value in csv file for each location changing
                writeCSV("/magnetometer.csv", "azimuth" + ", " + "pitch" + ", " + "roll" + ", " + "tesla", entry);
            }
            //when file couldn't be found we can see all the related reasons by logging all the errors
            catch (FileNotFoundException e)
            {
                e.printStackTrace();
            }
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int i)
        {
            ///nothing
        }
    };
}