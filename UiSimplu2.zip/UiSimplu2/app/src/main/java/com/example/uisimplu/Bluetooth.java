package com.example.uisimplu;

//import the libraries related to bluetooth sensors and devices
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;

//context an dintent libraries
import android.content.Context;
import android.content.Intent;

//file writing data library
import java.io.FileNotFoundException;


//create the Bluetooth class which inherit the base class Senzor
public class Bluetooth extends Senzor
{
    //class attributes

    //attributes related to bluetooth adapter and manager (bluetooth sensor)
    protected BluetoothAdapter BTAdapter = BluetoothAdapter.getDefaultAdapter();
    protected BluetoothManager bluetoothManager;

    //attribute for storing the rssi value
    protected    int rssi;

    //BroadcastReceiver object where we try to obtain the device address and rssi value
    protected final BroadcastReceiver receiver = new BroadcastReceiver()
    {
        @Override
        public void onReceive(Context context, Intent intent)
        {

            //conditional block where we process data obtaining only if the bluetooth device is active

            if (BluetoothDevice.ACTION_FOUND.equals(intent.getAction()))
            {
                //bluetooth strength
                rssi = intent.getShortExtra(BluetoothDevice.EXTRA_RSSI, Short.MIN_VALUE);
                //device address
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                //data written in csv line by line for each recorded point
                String entry = "\n"+ device.getAddress() + ", " + String.format("%d", rssi);
                try
                {
                    writeCSV("/bluetooth.csv", "address" + ", " + "rssi", entry);
                }

                //treat the exception for file inadvertency and print the possible stack errors

                catch (FileNotFoundException e)
                {
                    e.printStackTrace();
                }

            }
        }
    };

}