package com.example.uisimplu;


import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.location.LocationManager;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatDialogFragment;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;


//the PopUp class is created to save the pinpoint by writing its name in associated dialog of pop-up window
public class PopUpWindow extends AppCompatDialogFragment{

    private EditText editText;

    Accelerometer accelerometer = new Accelerometer();
    WifiSignal wifiSignal = new WifiSignal();
    Gyroscope gyroscope = new Gyroscope();
    Magnetometer magnetometer = new Magnetometer();
    Barometer barometer = new Barometer();
    Bluetooth bluetooth = new Bluetooth();
    StepCounter stepCounter = new StepCounter();
    Senzor senzor = new Senzor();


    //create dialog window where user type the name of pinpoint after press the pinpoint button
    public Dialog onCreateDialog(Bundle savedInstanceState){

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        LayoutInflater inflater = getActivity().getLayoutInflater();

        View view = inflater.inflate(R.layout.layout_dialog,null);

        builder.setView(view).setTitle("Save").setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        }).setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

                System.out.println("##############################");
                Log.i("Denumire", editText.getText().toString());
                System.out.println("##############################");

                String s = editText.getText().toString()+"\n";

                try {
                    senzor.writeCSV("/pinpoint1.csv", "", s);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }

                String entry = editText.getText().toString();
                try {
                    File path = new File("/storage/emulated/0/Download");
                    File file = new File(path + "/PinPoints.csv");
                    FileOutputStream f = new FileOutputStream(file, true);
                    try {
                        f.write(entry.getBytes());
                        f.flush();

                    }catch(Exception e){
                        e.printStackTrace();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        editText = view.findViewById(R.id.edit_locatie);

        return builder.create();

    }
}