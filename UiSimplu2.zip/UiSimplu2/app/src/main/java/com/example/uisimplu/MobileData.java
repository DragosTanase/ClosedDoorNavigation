package com.example.uisimplu;

//import telephony libraries
import android.telephony.PhoneStateListener;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;

//import file library
import java.io.FileNotFoundException;


//create the MobileData class which inherit the base class Senzor
public class MobileData extends Senzor
{
    //class attributes related to phone signal
    protected TelephonyManager telephoneManager;
    protected myPhoneStateListener pslistener;

    //inner class for PhoneStateListener  - telephony.phoneStateListener
    public class myPhoneStateListener extends PhoneStateListener
    {
        //signalStrenghtValue initialized with 0
        float signalStrengthValue = 0;

        //method that register signalStrength for every location changing
        public void onSignalStrengthsChanged(SignalStrength signalStrength)
        {
            //collect signal strength from sensor using specific getters
            this.signalStrengthValue = signalStrength.getCellSignalStrengths().get(0).getDbm();
            //store signal value in a string variable
            String entry = "\n" + String.format("%.3f", this.signalStrengthValue);
            try
            {
                //write string value in csv file as a line
                writeCSV("/mobileDATA.csv", "dbm", entry);
            }
            //when file couldn't be found we can see all the related reasons by logging all the errors
            catch (FileNotFoundException e)
            {
                e.printStackTrace();
            }
        }
    }
}