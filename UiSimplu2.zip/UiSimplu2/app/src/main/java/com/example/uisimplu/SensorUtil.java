package com.example.uisimplu;

import android.content.Context;

//import hardware library related to sensors
import android.hardware.SensorManager;

//import the stack library as we use the stored values in a LIFO manner
import java.util.Stack;

//create a class called SensorUtil
public class SensorUtil
{
    //class attributes
    private static final SensorUtil sensorUtil = new SensorUtil();
    private SensorManager sensorManager;
    private static final int SENSE = 10;
    private static final int STOP_COUNT = 6;
    private int initialOrient = -1;
    private int endOrient = -1;
    private boolean isRotating = false;
    private int lastDOrient = 0;
    private Stack<Integer> dOrientStack = new Stack<>();

    //implied constructor
    private SensorUtil()
    {
    }

    //class methods
    public static SensorUtil getInstance()
    {
        return sensorUtil;
    }

    //sensor manager getter from Context SENSOR_SERVICE
    public SensorManager getSensorManager(Context context)
    {
        if (sensorManager == null)
        {
            sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        }
        return sensorManager;
    }

    //get rotate End Orient
    public int getRotateEndOrient(int orient)
    {
        //if initial orient is -1 then endOrient is also -1
        if (initialOrient == -1)
        {
            endOrient = initialOrient = orient;

        }

        //obtain the current orient by substracting the initial orient from orient and make the module of the result
        int currentDOrient = Math.abs(orient - initialOrient);

        //if we haven't any rotation during the walk then lastOrient is the same as the current orient
        if (!isRotating)
        {
            lastDOrient = currentDOrient;
            if (lastDOrient >= SENSE)
            {
                isRotating = true;
            }
        }

        //if we have rotation(s) during the walk we have several cases
        else
        {
            //case when current orient is less or equal to last orient
            if (currentDOrient <= lastDOrient)
            {
                //get the size of the stack
                int size = dOrientStack.size();
                if (size >= STOP_COUNT)
                {
                    //
                    for (int i = 0; i < size; i++)
                    {
                        if (Math.abs(currentDOrient - dOrientStack.pop()) >= SENSE)
                        {
                            isRotating = true;
                            break;
                        }
                        isRotating = false;
                    }
                }
                //when we have any rotation the stack is cleared and initial orient becomes -1
                if (!isRotating)
                {
                    dOrientStack.clear();
                    initialOrient = -1;
                    endOrient = orient;
                }
                else
                {
                    //when we have rotations then we push into the stack the current orient
                    dOrientStack.push(currentDOrient);
                }
            }
            //case when current orient is greater than last orient
            else
            {
                lastDOrient = currentDOrient;
            }
        }
        return endOrient;
    }
}