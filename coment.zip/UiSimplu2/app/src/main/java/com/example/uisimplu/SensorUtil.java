package com.example.uisimplu;

import android.content.Context;
import android.hardware.SensorManager;
import java.util.Stack;

public class SensorUtil
{
    private static final SensorUtil sensorUtil = new SensorUtil();
    private SensorManager sensorManager;
    private static final int SENSE = 10;
    private static final int STOP_COUNT = 6;
    private int initialOrient = -1;
    private int endOrient = -1;
    private boolean isRotating = false;
    private int lastDOrient = 0;
    private Stack<Integer> dOrientStack = new Stack<>();
    private SensorUtil()
    {
    }

    public static SensorUtil getInstance()
    {
        return sensorUtil;
    }


    public SensorManager getSensorManager(Context context)
    {
        if (sensorManager == null)
        {
            sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        }
        return sensorManager;
    }

    public int getRotateEndOrient(int orient)
    {
        if (initialOrient == -1)
        {
            endOrient = initialOrient = orient;

        }

        int currentDOrient = Math.abs(orient - initialOrient);
        if (!isRotating)
        {
            lastDOrient = currentDOrient;
            if (lastDOrient >= SENSE)
            {
                isRotating = true;
            }
        }
        else
        {
            if (currentDOrient <= lastDOrient)
            {
                int size = dOrientStack.size();
                if (size >= STOP_COUNT)
                {
                    for (int i = 0; i < size; i++)
                    {
                        if (Math.abs(currentDOrient - dOrientStack.pop()) >= SENSE)
                        {
                            isRotating = true;
                            break;
                        }
                        isRotating = false;
                    }
                }
                if (!isRotating)
                {
                    dOrientStack.clear();
                    initialOrient = -1;
                    endOrient = orient;
                }
                else
                {
                    dOrientStack.push(currentDOrient);
                }
            }
            else
            {
                lastDOrient = currentDOrient;
            }
        }
        return endOrient;
    }
}