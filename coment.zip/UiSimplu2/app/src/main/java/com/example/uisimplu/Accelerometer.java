package com.example.uisimplu;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import java.io.FileNotFoundException;

public class Accelerometer extends Senzor
{
    protected SensorManager mSensorManager;
    protected Sensor mAccelerator;

    protected  float xAccelerometer;
    protected float yAccelerometer;
    protected float zAccelerometer;

    Accelerometer(){};

    protected SensorEventListener sensorEventListener = new SensorEventListener()
    {
        @Override
        public void onSensorChanged(SensorEvent sensorEvent)
        {
            ///data sent to csv file
            xAccelerometer = sensorEvent.values[0];
            yAccelerometer = sensorEvent.values[1];
            zAccelerometer = sensorEvent.values[2];
            String entry = "\n" + String.format("%.2f", xAccelerometer) + "," + String.format("%.2f", yAccelerometer) + "," + String.format("%.2f", zAccelerometer);
            try
            {
                //writing data only when moving
                if(xAccelerometer!=0.00 && yAccelerometer!=9.81)
                {
                    writeCSV("/accelerometer.csv", "X" + ", " + "Y" + ", " + "Z", entry);
                }
            }
            catch (FileNotFoundException e)
            {
                e.printStackTrace();
            }
        }
        @Override
        public void onAccuracyChanged(Sensor sensor, int i)
        {
            //nothing
        }
    };



}