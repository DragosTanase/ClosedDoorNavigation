package com.example.uisimplu;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.util.Log;

import java.util.List;
import java.util.Stack;


public class SensorUtil {

    protected static final SensorUtil sensorUtil = new SensorUtil(); // 单例常量
    protected SensorManager sensorManager;

    private static final int SENSE = 10; // 方向差值灵敏度
    private static final int STOP_COUNT = 6; // 停止次数
    private int initialOrient = -1; // 初始方向
    private int endOrient = -1; // 转动停止方向

    private boolean isRotating = false; // 是否正在转动
    private int lastDOrient = 0; // 上次方向与初始方向差值
    private Stack<Integer> dOrientStack = new Stack<>(); // 历史方向与初始方向的差值栈

    private SensorUtil() {
    }

    public static SensorUtil getInstance() {
        return sensorUtil;
    }

    public int getRotateEndOrient(int orient) {
        if (initialOrient == -1) {

            endOrient = initialOrient = orient;

        }

        int currentDOrient = Math.abs(orient - initialOrient);
        if (!isRotating) {

            lastDOrient = currentDOrient;
            if (lastDOrient >= SENSE) {

                isRotating = true;
            }
        } else {

            if (currentDOrient <= lastDOrient) {

                int size = dOrientStack.size();
                if (size >= STOP_COUNT) {

                    for (int i = 0; i < size; i++) {
                        if (Math.abs(currentDOrient - dOrientStack.pop()) >= SENSE) {
                            isRotating = true;
                            break;
                        }
                        isRotating = false;
                    }
                }

                if (!isRotating) {

                    dOrientStack.clear();
                    initialOrient = -1;
                    endOrient = orient;

                } else {

                    dOrientStack.push(currentDOrient);

                }
            } else {
                lastDOrient = currentDOrient;
            }
        }
        return endOrient;
    }
}