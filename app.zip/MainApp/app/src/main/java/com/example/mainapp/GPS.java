package com.example.mainapp;

import android.location.Location;
import android.location.LocationManager;
import android.widget.TextView;

public class GPS {
    protected LocationManager locationManager;
    protected TextView txtLat;
    protected Location location;
    protected boolean o = true;
    GPS(){};
}
