package com.example.uisimplu;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

public class Canvas extends View {
    Paint paint;
    public Canvas(Context context) {
        super(context);
        init();
    }

    public Canvas(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public void  init()
    {
        paint=new Paint();
        paint.setColor(Color.RED);
        paint.setStrokeWidth(8);
        paint.setStyle(Paint.Style.FILL);
    }

    @Override
    protected void onDraw(android.graphics.Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawColor(Color.WHITE);
        canvas.drawCircle(this.getWidth()/2,this.getHeight()/2,10,paint);
    }
}
