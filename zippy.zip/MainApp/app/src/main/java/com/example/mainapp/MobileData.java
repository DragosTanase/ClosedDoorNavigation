package com.example.mainapp;

import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;

public class MobileData {
    TextView txt1;
    TelephonyManager TelephoneManager;
    myPhoneStateListener pslistener;
    int SignalStrength = 0;

    MobileData() {
    }

    class myPhoneStateListener extends PhoneStateListener {
        public void onSignalStrengthsChanged(android.telephony.SignalStrength signalStrength) {
            super.onSignalStrengthsChanged(signalStrength);
            SignalStrength = signalStrength.getGsmSignalStrength();
            SignalStrength = (2 * SignalStrength) - 113;
            txt1.setText(String.valueOf(SignalStrength + "dBm"));
            String entry = "\n" + String.format("%.3f dBm", SignalStrength);
            try {

                File path = new File("/storage/emulated/0/Download");
                File file = new File(path + "/GSM.csv");
                FileOutputStream f = new FileOutputStream(file, true);
                try {

                    f.write(entry.getBytes());
                    f.flush();

                } catch (Exception e) {
                    e.printStackTrace();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}