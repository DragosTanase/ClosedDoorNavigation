package com.example.mainapp;

import android.location.LocationManager;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.location.FusedLocationProviderClient;


public class GPS extends AppCompatActivity {

    protected TextView textViewLatitude, textViewLongitude;
    protected LocationManager locationManager;
    protected FusedLocationProviderClient MyFusedLocationClient;

    GPS() {
    }

    ;


}

