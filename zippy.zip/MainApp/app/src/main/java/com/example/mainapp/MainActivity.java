package com.example.mainapp;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;


public class MainActivity extends AppCompatActivity {

    StepCounter steps = new StepCounter();
    Accelerometer acc = new Accelerometer();
    WifiSignal wifi = new WifiSignal();
    Barometer bar = new Barometer();
    Gyroscope gyr = new Gyroscope();
    Magnetometer mag = new Magnetometer();

    MobileData data = new MobileData();
    GPS gps = new GPS();


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_DENIED) { //ask for permission
            requestPermissions(new String[]{Manifest.permission.ACTIVITY_RECOGNITION}, 0);
        }
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.MANAGE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) { //ask for permission
            requestPermissions(new String[]{Manifest.permission.MANAGE_EXTERNAL_STORAGE}, 0);
        }
        ///GPS

        ///StepCounter
        steps.textViewStepCounter = findViewById(R.id.stpCount);
        steps.msensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        steps.mStepCounter = steps.msensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        ///Accelerometer
        acc.txt_X = findViewById(R.id.txt_X);
        acc.txt_Y = findViewById(R.id.txt_Y);
        acc.txt_Z = findViewById(R.id.txt_Z);
        acc.mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        acc.mAccelerator = acc.mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        ///Gyroscope
        gyr.txt_X_gyroscope = findViewById(R.id.txt_X_gyroscope);
        gyr.txt_Y_gyroscope = findViewById(R.id.txt_Y_gyroscope);
        gyr.txt_Z_gyroscope = findViewById(R.id.txt_Z_gyroscope);
        gyr.mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        gyr.mGyroscope = gyr.mSensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        ///Barometer
        bar.txtPressure = findViewById(R.id.txtPressure);
        bar.sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        bar.pressureSensor = bar.sensorManager.getDefaultSensor(Sensor.TYPE_PRESSURE);
        ///Wifi
        wifi.textStrength = findViewById(R.id.textStrength);
        wifi.wifiManager = (WifiManager) this.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        ///Magnetometer
        mag.tesla_txt = (TextView) findViewById(R.id.tesla_txt);
        mag.azimuth_txt = (TextView) findViewById(R.id.azimuth_txt);
        mag.roll_txt = (TextView) findViewById(R.id.roll_txt);
        mag.pitch_txt = (TextView) findViewById(R.id.pitch_txt);
        mag.magSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        mag.magSensor = mag.magSensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);

        ///Mobile


        Handler mainHandler = new Handler(Looper.getMainLooper());
        final Runnable r = new Runnable() {
            @Override
            public void run() {
                wifi.displayWifiData();
                mainHandler.postDelayed(this, 1000);
            }
        };

        mainHandler.postDelayed(r, 1);

    }

    protected void onResume() {
        super.onResume();
        steps.msensorManager.registerListener(steps.sensorEventListener, steps.mStepCounter, SensorManager.SENSOR_DELAY_NORMAL);
        acc.mSensorManager.registerListener(acc.sensorEventListener, acc.mAccelerator, SensorManager.SENSOR_DELAY_NORMAL);
        bar.sensorManager.registerListener(bar.sensorEventListener, bar.pressureSensor, SensorManager.SENSOR_DELAY_UI);
        gyr.mSensorManager.registerListener(gyr.sensorEventListener, gyr.mGyroscope, SensorManager.SENSOR_DELAY_NORMAL);
        mag.magSensorManager.registerListener(mag.sensorEventListener, mag.magSensor, SensorManager.SENSOR_DELAY_NORMAL);

    }

    @Override
    protected void onPause() {
        super.onPause();
        steps.msensorManager.unregisterListener(steps.sensorEventListener, steps.mStepCounter);
    }
}