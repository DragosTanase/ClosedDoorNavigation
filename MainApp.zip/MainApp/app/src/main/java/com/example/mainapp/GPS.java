package com.example.mainapp;

import android.location.Location;
import android.location.LocationManager;

import java.io.FileNotFoundException;

public class GPS extends Senzor{
    protected LocationManager locationManager;
    protected Location location;
}
